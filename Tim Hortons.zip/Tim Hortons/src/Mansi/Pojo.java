package Mansi;

import java.util.ArrayList;
import java.util.List;

public class Pojo {
	List<String> Names=new ArrayList<String>();
	public List<String> getNames() {
		return Names;
	}
	public void setNames(List<String> names) {
		Names = names;
	}
}
